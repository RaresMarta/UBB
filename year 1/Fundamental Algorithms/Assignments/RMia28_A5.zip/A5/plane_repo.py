from plane import *
from utils import *


class PlaneRepository:
    def __init__(self):
        self.__planes = []
        self.__planes_nr = 0

    def get_planes(self):
        return self.__planes

    def get_planes_number(self):
        return self.__planes_nr

    def set_planes(self, planes):
        self.__planes = planes

    def set_planes_number(self, planes_nr):
        self.__planes_nr = planes_nr

    def add_plane(self, new_plane):
        """
        Adds a plane to the repository
        :param new_plane: plane object
        """
        self.__planes.append(new_plane)
        self.__planes_nr += 1

    def add_passenger(self, plane_index, new_passenger):
        """
        Adds a passenger to the plane
        :param plane_index: integer
        :param new_passenger: passenger object
        """
        passengers_list = self.__planes[plane_index].get_passengers()
        passengers_list.append(new_passenger)
        self.__planes[plane_index].set_passengers(passengers_list)

    def update_plane(self, plane_index, new_plane):
        """
        Updates a plane in the repository
        :param plane_index: integer
        :param new_plane: plane object
        """
        self.__planes[plane_index] = new_plane

    def update_passenger(self, plane_index, passenger_index, new_passenger):
        """
        Updates a passenger in the plane
        :param plane_index: integer
        :param passenger_index: integer
        :param new_passenger: passenger object
        """
        self.__planes[plane_index].get_passengers()[passenger_index] = new_passenger

    def remove_plane(self, index):
        """
        Removes a plane from the repository
        :param index: integer
        """
        self.__planes.pop(index)
        self.__planes_nr -= 1

    def remove_passenger(self, plane_index, passenger_index):
        """
        Removes a passenger from the plane
        :param plane_index: integer
        :param passenger_index: integer
        """
        plane_passengers = self.__planes[plane_index].get_passengers()
        plane_passengers.pop(passenger_index)
        self.__planes[plane_index].set_passengers(plane_passengers)

    def general_sort(self, lst, key):
        quicksort(lst, key, 0, len(lst) - 1)
        return lst

    def general_filter(self, lst, key):
        return list(filter(key, lst))

    def sort_passengers_by_last_name(self, plane_index):
        """
        Sorts passengers by last name
        :param plane_index: integer
        """
        pass_list = self.__planes[plane_index].get_passengers()
        sorted_passengers = self.general_sort(pass_list, lambda x: x.get_last_name())
        self.__planes[plane_index].set_passengers(sorted_passengers)

    def sort_planes_by_passengers_number(self):
        """
        Sort planes by the number of passengers
        """
        self.__planes = self.general_sort(self.__planes, lambda x: len(x.get_passengers()))

    def sort_planes_by_passengers_number_with_prefix(self, prefix):
        """
        Sort planes by the number of passengers with the first name starting with a given prefix
        :param prefix: string
        """
        self.__planes = self.general_sort(self.__planes, lambda x: x.get_passengers_number_with_prefix(prefix))

    def sort_planes_by_concatenated_string(self):
        """
        Sort planes according to the string obtained by concatenation of the number of
        passengers in the plane and the destination
        """
        self.__planes = self.general_sort(self.__planes, lambda x: x.concatenated_string())

    def filter_planes_by_passenger_passport(self):
        """
        Filter planes that have passengers with passport numbers starting with the same 3 letters
        """
        return self.general_filter(self.__planes, lambda x: x.matching_passports())

    def filter_passengers_containing_string(self, string, plane_index):
        """
        Filter passengers from a given plane for which the first name or last
        name contain a string given as a parameter
        :param string: string
        :param plane_index: integer
        """
        pass_list = self.__planes[plane_index].get_passengers()
        return self.general_filter(pass_list, lambda x: x.contains_string(string))

    def filter_plane_with_passenger(self, first_name, last_name):
        """
        Filter planes that contain a given passenger
        :param first_name: string
        :param last_name: string
        """
        return self.general_filter(self.__planes, lambda x: x.contains_passenger(first_name, last_name))

    def passengers_group(self, plane_index, k):
        """
        Form groups of k passengers with different last names from a given plane
        :param plane_index: integer
        :param k: integer
        :return: list
        """
        result = []
        lst = self.__planes[plane_index].get_passengers()
        bk(lst, [], k, check_different_last_names, result)
        return result

    def planes_group(self, k):
        """
        Form groups of k planes with the same destination but having different airline companies
        :param k: integer
        :return: list
        """
        result = []
        lst = self.__planes
        bk(lst, [], k, check_dest_and_company, result)
        return result

    def load_predefined_planes(self):
        """
        Loads predefined planes
        """
        self.__planes.append(Plane(0, 'ABC Airlines', 150, 'New York', []))
        self.__planes.append(Plane(1, 'XYZ Airways', 200, 'London', []))
        self.__planes.append(Plane(2, 'PQR Flights', 180, 'Paris', []))
        self.__planes.append(Plane(3, 'COX Airlines', 250, 'New York', []))
        self.__planes.append(Plane(4, 'DEF Flights', 75, 'Rome', []))
        self.__planes.append(Plane(5, 'GHI Airlines', 100, 'Moscow', []))
        self.__planes.append(Plane(6, 'JKL Flights', 120, 'Tokyo', []))
        self.__planes.append(Plane(7, 'MNO Airlines', 90, 'Sydney', []))
        self.__planes.append(Plane(8, 'DEF Flights', 75, 'Rome', []))
        self.__planes.append(Plane(9, 'GHI Airlines', 100, 'Moscow', []))
        self.__planes_nr = 10

    def load_predefined_passengers(self):
        """
        Loads predefined passengers
        """
        p1 = Passenger('John', 'Doe', '123456789')
        p2 = Passenger('Jane', 'Doe', '123654321')
        p3 = Passenger('Mike', 'Smith', '123456789')
        p4 = Passenger('Sarah', 'Johnson', '987654321')
        p5 = Passenger('Emily', 'Brown', '123456789')
        p6 = Passenger('Olivia', 'Davis', '987654321')

        self.__planes[0].set_passengers([p1, p2])
        self.__planes[1].set_passengers([p3])
        self.__planes[2].set_passengers([p4, p5, p6])
        self.__planes[3].set_passengers([p1, p2, p3, p6])
        self.__planes[4].set_passengers([p4, p5])
        self.__planes[5].set_passengers([p1, p2, p3, p4, p5, p6])

    def get_passenger_data(self, plane_index):
        """
        Get data of passengers from a given plane
        :param plane_index: integer
        :return temp_list: list of strings
        """
        temp_list = []

        for pas in self.__planes[plane_index].get_passengers():
            first_name = pas.get_first_name()
            last_name = pas.get_last_name()
            passport = pas.get_passport_nr()
            temp_list.append(name_blanks(first_name) + name_blanks(last_name) + name_blanks(passport))

        print("")
        for i in range(len(temp_list)):
            print(temp_list[i])
        print("")
        return temp_list

    def print_planes(self):
        """
        Print planes in the repository
        """
        temp_list = []

        for plane in self.__planes:
            nr = plane.get_number()
            company = plane.get_company()
            seats = plane.get_seats_nr()
            dest = plane.get_destination()
            pass_nr = plane.get_passengers_number()
            temp_list.append(
                nr_blanks(nr) + cp_blanks(company) + st_blanks(seats) + name_blanks(dest) + f"({pass_nr} pgs)")

        print("")
        for i in range(len(temp_list)):
            print(temp_list[i])
        print("")

        return temp_list
