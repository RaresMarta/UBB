class Passenger:
    def __init__(self, first_name, last_name, passport_nr):
        self.__first_name = first_name
        self.__last_name = last_name
        self.__passport_nr = passport_nr

    def get_first_name(self):
        return self.__first_name

    def get_last_name(self):
        return self.__last_name

    def get_passport_nr(self):
        return self.__passport_nr

    def set_first_name(self, first_name):
        self.__first_name = first_name

    def set_last_name(self, last_name):
        self.__last_name = last_name

    def set_passport_nr(self, passport_nr):
        self.__passport_nr = passport_nr

    def contains_string(self, string):
        return string in self.__first_name or string in self.__last_name

    def __str__(self):
        print(f"{self.__first_name} {self.__last_name} {self.__passport_nr}")
