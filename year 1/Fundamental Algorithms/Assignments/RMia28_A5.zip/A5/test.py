from plane import Plane
from passenger import Passenger
from plane_repo import *


def test_plane_repository():
    plane_repo = PlaneRepository()
    plane1 = Plane(1, 'ABC Airlines', 150, 'New York', [])
    plane2 = Plane(2, 'XYZ Airways', 200, 'London', [])
    plane3 = Plane(3, 'PQR Flights', 180, 'Paris', [])
    plane4 = Plane(4, 'LMN Airlines', 250, 'Berlin', [])
    plane5 = Plane(5, 'DEF Flights', 75, 'Rome', [])
    plane6 = Plane(6, 'GHI Airlines', 100, 'Moscow', [])

    # Test add_plane

    plane_repo.add_plane(plane1)
    assert len(plane_repo.get_planes()) == 1

    plane_repo.add_plane(plane2)
    assert len(plane_repo.get_planes()) == 2

    plane_repo.add_plane(plane3)
    assert len(plane_repo.get_planes()) == 3

    # Test add_passenger

    new_passenger = Passenger('John', 'Doe', '123456789')
    plane_repo.add_passenger(0, new_passenger)
    assert len(plane_repo.get_planes()[0].get_passengers()) == 1

    new_passenger = Passenger('Jane', 'Doe', '987654321')
    plane_repo.add_passenger(1, new_passenger)
    assert len(plane_repo.get_planes()[1].get_passengers()) == 1

    new_passenger = Passenger('Mike', 'Smith', '123456789')
    plane_repo.add_passenger(1, new_passenger)
    assert len(plane_repo.get_planes()[1].get_passengers()) == 2

    # Test update_plane

    plane_repo.update_plane(0, plane4)
    updated_plane = plane_repo.get_planes()[0]
    assert updated_plane.get_destination() == 'Berlin' and updated_plane.get_seats_nr() == 250

    plane_repo.update_plane(1, plane5)
    updated_plane = plane_repo.get_planes()[1]
    assert updated_plane.get_destination() == 'Rome' and updated_plane.get_seats_nr() == 75

    plane_repo.update_plane(2, plane6)
    updated_plane = plane_repo.get_planes()[2]
    assert updated_plane.get_destination() == 'Moscow' and updated_plane.get_seats_nr() == 100

    # Test update_passenger

    plane_repo.load_predefined_planes()

    temp_passenger = Passenger('Mike', 'Smith', '987654321')
    plane_repo.add_passenger(0, temp_passenger)
    new_passenger = Passenger('John', 'Doe', '123456789')
    plane_repo.update_passenger(0, 0, new_passenger)
    assert plane_repo.get_planes()[0].get_passengers()[0].get_first_name() == 'John'

    temp_passenger = Passenger('Alex', 'Parker', '123456789')
    plane_repo.add_passenger(0, temp_passenger)
    new_passenger = Passenger('Victoria', 'Garcia', '987654321')
    plane_repo.update_passenger(0, 1, new_passenger)
    assert plane_repo.get_planes()[0].get_passengers()[1].get_first_name() == 'Victoria'

    temp_passenger = Passenger('Mike', 'Smith', '123456789')
    plane_repo.add_passenger(0, temp_passenger)
    new_passenger = Passenger('Kate', 'Zhao', '987654321')
    plane_repo.update_passenger(0, 2, new_passenger)
    assert plane_repo.get_planes()[0].get_passengers()[2].get_first_name() == 'Kate'

    # Test remove_passenger

    plane_repo.remove_passenger(0, 2)
    assert len(plane_repo.get_planes()[0].get_passengers()) == 2

    plane_repo.remove_passenger(0, 1)
    assert len(plane_repo.get_planes()[0].get_passengers()) == 1

    plane_repo.remove_passenger(0, 0)
    assert len(plane_repo.get_planes()[0].get_passengers()) == 0

    # Test remove_plane

    plane_repo.load_predefined_planes()

    plane_repo.remove_plane(0)
    assert plane_repo.get_planes_number() == 9

    plane_repo.remove_plane(1)
    assert plane_repo.get_planes_number() == 8

    plane_repo.remove_plane(2)
    assert plane_repo.get_planes_number() == 7

    # Test sort_passengers_by_last_name

    plane_repo.add_passenger(0, Passenger('John', 'Doe', '123456789'))
    plane_repo.add_passenger(0, Passenger('Jane', 'Alex', '987654321'))
    plane_repo.add_passenger(0, Passenger('Mike', 'Smith', '123456789'))

    plane_repo.sort_passengers_by_last_name(0)

    assert plane_repo.get_planes()[0].get_passengers()[0].get_last_name() == 'Alex'
    assert plane_repo.get_planes()[0].get_passengers()[1].get_last_name() == 'Doe'
    assert plane_repo.get_planes()[0].get_passengers()[2].get_last_name() == 'Smith'

    # Test sort_planes_by_passengers_number

    r = PlaneRepository()
    r.add_plane(Plane(1, "A", 100, 'Rome', []))
    r.add_plane(Plane(2, "B", 200, 'Moscow', []))
    r.add_plane(Plane(3, "C", 300, 'Berlin', []))
    r.add_passenger(0, Passenger('John', 'Doe', '123456789'))
    r.add_passenger(0, Passenger('Jane', 'Alex', '987654321'))
    r.add_passenger(0, Passenger('Mike', 'Smith', '123456789'))
    r.add_passenger(1, Passenger('John', 'Doe', '123456789'))
    r.add_passenger(2, Passenger('John', 'Doe', '123456789'))
    r.add_passenger(2, Passenger('Jane', 'Alex', '987654321'))

    assert len(r.get_planes()[0].get_passengers()) == 3
    assert len(r.get_planes()[1].get_passengers()) == 1
    assert len(r.get_planes()[2].get_passengers()) == 2

    r.sort_planes_by_passengers_number()

    assert len(r.get_planes()[0].get_passengers()) == 1
    assert len(r.get_planes()[1].get_passengers()) == 2
    assert len(r.get_planes()[2].get_passengers()) == 3

    # Test sort_planes_by_passengers_number_with_prefix

    plane_repo = PlaneRepository()
    plane_repo.load_predefined_planes()
    plane_repo.load_predefined_passengers()

    plane_repo.add_passenger(0, Passenger('Jane', 'Doe', '111111111'))

    prefix = 'J'
    plane_repo.sort_planes_by_passengers_number_with_prefix(prefix)

    assert plane_repo.get_planes()[9].get_passengers_number_with_prefix(prefix) == 3
    assert plane_repo.get_planes()[8].get_passengers_number_with_prefix(prefix) == 2
    assert plane_repo.get_planes()[7].get_passengers_number_with_prefix(prefix) == 2

    # Test planes_group

    plane_repo = PlaneRepository()
    plane_repo.load_predefined_planes()
    plane_repo.load_predefined_passengers()

    result = plane_repo.planes_group(2)
    plane1 = plane_repo.get_planes()[0]
    plane2 = plane_repo.get_planes()[3]

    expected_result = [[plane1, plane2], [plane2, plane1]]

    assert result == expected_result

    # Test passenger_group

    repo = PlaneRepository()
    repo.add_plane(Plane(0, 'ABC Airlines', 150, 'New York', []))
    p1 = Passenger('John', 'Doe', '123456789')
    p2 = Passenger('Mike', 'Smith', '123456789')
    p3 = Passenger('Sarah', 'Johnson', '987654321')
    p4 = Passenger('Emily', 'Brown', '123456789')
    repo.add_passenger(0, p1)
    repo.add_passenger(0, p2)
    repo.add_passenger(0, p3)
    repo.add_passenger(0, p4)

    result = repo.passengers_group(0, 2)
    assert len(result) == 12


# Run the tests
test_plane_repository()

print("All tests passed!")
