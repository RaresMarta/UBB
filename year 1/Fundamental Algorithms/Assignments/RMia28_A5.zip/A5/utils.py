from plane import *
from passenger import *


def read_option():
    # Input function for option in the UI
    try:
        op = int(input("Choose an option: "))
        if 0 <= op <= 17:
            return op
        else:
            raise ValueError
    except ValueError:
        print("Invalid option")
        return read_option()


def read_number():
    # Input function for number in the UI
    try:
        nr = int(input("Enter number: "))
        if 0 <= nr and isinstance(nr, int):
            return nr
        else:
            raise ValueError
    except ValueError:
        print("Invalid number")
        return read_number()


def read_company():
    # Input function for company in the UI
    try:
        cp = input("Enter company: ")
        if len(cp) > 0:
            return cp
        else:
            raise ValueError
    except ValueError:
        print("Invalid company")
        return read_company()


def read_seats():
    # Input function for seats in the UI
    try:
        st = int(input("Enter number of seats: "))
        if 0 <= st and isinstance(st, int):
            return st
        else:
            raise ValueError
    except ValueError:
        print("Invalid number of seats")
        return read_seats()


def read_destination():
    # Input function for destination in the UI
    try:
        dest = input("Enter destination: ")
        if len(dest) > 0:
            return dest
        else:
            raise ValueError
    except ValueError:
        print("Invalid destination")
        return read_destination()


def read_plane_index(repo):
    # Input function for plane index in the UI
    try:
        plane_index = int(input("Choose a plane: "))
        crt = repo.get_planes_number()
        if crt > 0 and 0 <= plane_index <= crt:
            return plane_index
        else:
            raise ValueError
    except ValueError:
        print("Invalid plane index")
        return read_plane_index(repo)


def read_passenger_index(repo, plane_index):
    # Input function for passenger index in the UI
    try:
        passenger_index = int(input("Enter passenger index: "))
        crt = repo.get_planes()[plane_index].get_passengers_number()
        if crt > 0 and 0 <= passenger_index < crt:
            return passenger_index
        else:
            raise ValueError
    except ValueError:
        print("Invalid passenger index")
        read_passenger_index(repo, plane_index)


def divisors_number(number):
    """
    Calculates the number of divisors of a number
    :param number: integer
    :return: integer
    """
    div = 0
    for i in range(2, number // 2 + 1):
        if number % i == 0:
            div += 1
    return div


def quicksort(array, key, start, end):
    """
    Sorts an array using quicksort
    :param array: list
    :param key: function
    :param start: integer
    :param end: integer
    :return: None
    """
    if start >= end:
        return

    pivot = partition(array, key, start, end)
    quicksort(array, key, start, pivot - 1)
    quicksort(array, key, pivot + 1, end)


def partition(array, key, start, end):
    """
    Partitions an array using quicksort
    :return i: integer - pivot index
    """
    pivot = array[end]
    i = start - 1

    for j in range(start, end):
        if key(array[j]) <= key(pivot):
            i += 1
            array[i], array[j] = array[j], array[i]

    i += 1
    array[i], array[end] = array[end], array[i]

    return i


def cp_blanks(string):
    """
    Adds spaces to a string
    :param string: string
    :return: string
    """
    string = str(string)
    for i in range(15 - len(string)):
        string += " "
    return string


def st_blanks(string):
    """
    Adds spaces to a string
    :param string: string
    :return: string
    """
    string = str(string)
    for i in range(6 - len(string)):
        string += " "
    return string


def nr_blanks(string):
    """
    Adds spaces to a string
    :param string: string
    :return: string
    """
    string = str(string)
    for i in range(4 - len(string)):
        string += " "
    return string


def name_blanks(string):
    """
    Adds spaces to a string
    :param string: string
    :return: string
    """
    string = str(string)
    for i in range(10 - len(string)):
        string += " "
    return string


def check_different_last_names(lst):
    """
    Checks whether all the passengers from a list have different last names
    :param lst: list
    :return: boolean
    """
    n = len(lst)
    for i in range(n - 1):
        for j in range(i + 1, n):
            if lst[i].get_last_name() == lst[j].get_last_name():
                return False
    return True


def check_dest_and_company(lst):
    """
    Checks whether all the planes from a list have the same destination and different airline company
    :param lst: list
    :return: boolean
    """
    n = len(lst)
    for i in range(n - 1):
        for j in range(i + 1, n):
            if lst[i].get_destination() != lst[j].get_destination() or lst[i].get_company() == lst[j].get_company():
                return False
    return True


def bk(lst, gen, k, cond, result):
    """
    Backtracking function for general grouping
    :param lst: list
    :param cond: function
    :param k: integer
    :param gen: generator
    :param result: list
    """

    if k == len(gen) and cond(gen):
        result.append(gen[:])

    else:
        for i in lst:
            aux_list = gen.copy()
            aux_list.append(i)
            if cond(aux_list):
                gen.append(i)
                bk(lst, gen, k, cond, result)
                gen.pop()
