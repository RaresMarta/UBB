from passenger import *


class Plane:
    def __init__(self, number, company, seats_nr, destination, passengers: list):
        self.__number = number
        self.__company = company
        self.__seats_nr = seats_nr
        self.__destination = destination
        self.__passengers = passengers.copy()

    def get_number(self):
        return self.__number

    def get_seats_nr(self):
        return self.__seats_nr

    def get_company(self):
        return self.__company

    def get_destination(self):
        return self.__destination

    def get_passengers(self):
        return self.__passengers

    def get_passengers_number(self):
        return len(self.__passengers)

    def set_number(self, number):
        self.__number = number

    def set_seats_nr(self, seats_nr):
        self.__seats_nr = seats_nr

    def set_company(self, company):
        self.__company = company

    def set_destination(self, destination):
        self.__destination = destination

    def set_passengers(self, passengers):
        self.__passengers = passengers.copy()

    def passengers_starting_with_string(self, string):
        """
        Returns the number of passengers in the plane with first name starting with a given string
        :param string: string
        :return: integer
        """
        nr = 0
        for passenger in self.__passengers:
            if passenger.get_first_name().startswith(string):
                nr += 1
        return nr

    def concatenated_string(self):
        """
        Concatenates the number of passengers in the plane and the destination
        :return: string
        """
        return str(self.get_passengers_number()) + self.get_destination()

    def get_passengers_number_with_prefix(self, prefix):
        """
        Returns the number of passengers in the plane with first name starting with a given prefix
        :param prefix: string
        :return: integer
        """
        nr = 0
        for passenger in self.__passengers:
            if passenger.get_first_name().startswith(prefix):
                nr += 1
        return nr

    def matching_passports(self):
        """
        Check if a plane has passengers with passport numbers starting with the same 3 letters
        """
        pass_list = self.get_passengers()
        if pass_list:
            first3letters = pass_list[0].get_passport_nr()[0:3]
            nr = 0
            for pas in pass_list:
                if pas.get_passport_nr()[0:3] == first3letters:
                    nr += 1
            if nr == len(pass_list):
                return True
        return False

    def contains_passenger(self, first_name, last_name):
        """
        Check if a plane contains a given passenger
        :param first_name: string
        :param last_name: string
        """
        pass_list = self.get_passengers()
        if pass_list:
            for pas in pass_list:
                if pas.get_first_name() == first_name and pas.get_last_name() == last_name:
                    return True
        return False

    def __str__(self):
        return f"{self.__number} {self.__company} {self.__seats_nr} {self.__destination}"
