from plane import *
from passenger import *
from plane_repo import *
from utils import *


def print_menu():
    print("1. Print planes")
    print("2. Print passengers in a plane")
    print("3. Add a plane")
    print("4. Add a passenger to a plane")
    print("5. Update a plane")
    print("6. Update a passenger")
    print("7. Remove a plane")
    print("8. Remove a passenger from a plane")
    print("9. Sort passengers in a plane by last name")
    print("10. Sort planes by number of passengers")
    print("11. Sort planes by number of passengers with a given prefix")
    print("12. Sort planes by concatenated string")
    print("13. Identify  planes  that  have  passengers  with  passport  numbers  starting  with  the same 3 letters")
    print("14. Identify  passengers  from  a  given  plane  for  which  the  first  name  or  last  name contain a string given as parameter")
    print("15. Identify plane/planes where there is a passenger with given name")
    print("16. Form groups of 𝒌passengers from the same plane but with different last names")
    print("17. Form  groups  of 𝒌planes  with  the  same  destination  but  belonging  to  different airline companies")
    print("0. Exit")


def user_interface():
    repo = PlaneRepository()
    repo.load_predefined_planes()
    repo.load_predefined_passengers()
    print_menu()
    option = -2

    while option != 0:
        option = read_option()

        if option == 0:
            print("Exiting the program.")
            break

        elif option == 1:
            repo.print_planes()

        elif option == 2:
            plane_index = read_plane_index(repo)
            repo.get_passenger_data(plane_index)

        elif option == 3:
            # Add a Plane
            number = int(input("Enter plane number: "))
            company = input("Enter company: ")
            seats_nr = int(input("Enter number of seats: "))
            destination = input("Enter destination: ")
            plane = Plane(number, company, seats_nr, destination, [])
            repo.add_plane(plane)

        elif option == 4:
            # Add a Passenger to a Plane
            plane_index = read_plane_index(repo)
            first_name = input("Enter passenger's first name: ")
            last_name = input("Enter passenger's last name: ")
            passport_nr = input("Enter passenger's passport number: ")
            new_passenger = Passenger(first_name, last_name, passport_nr)
            repo.add_passenger(plane_index, new_passenger)

        elif option == 5:
            # Update a Plane
            plane_index = read_plane_index(repo)
            nr = read_number()
            company = read_company()
            seats = read_seats()
            destination = read_destination()
            repo.update_plane(plane_index, Plane(nr, company, seats, destination, []))

        elif option == 6:
            # Update a Passenger
            plane_index = read_plane_index(repo)
            passenger_index = read_passenger_index(repo, plane_index)
            new_first_name = input("Enter new first name: ")
            new_last_name = input("Enter new last name: ")
            new_passport_nr = input("Enter new passport number: ")
            updated_passenger = Passenger(new_first_name, new_last_name, new_passport_nr)
            repo.update_passenger(plane_index, passenger_index, updated_passenger)

        elif option == 7:
            # Remove a Plane
            plane_index = read_plane_index(repo)
            repo.remove_plane(plane_index)

        elif option == 8:
            # Remove a Passenger from a Plane
            plane_index = read_plane_index(repo)
            passenger_index = int(input("Enter passenger index: "))
            repo.remove_passenger(plane_index, passenger_index)
            print("")

        elif option == 9:
            # Sort Passengers in a Plane by Last Name
            plane_index = read_plane_index(repo)
            repo.sort_passengers_by_last_name(plane_index)
            print("")

        elif option == 10:
            # Sort Planes by Number of Passengers
            repo.sort_planes_by_passengers_number()
            print("")

        elif option == 11:
            # Sort Planes by Number of Passengers with a given prefix
            prefix = input("Enter prefix: ")
            repo.sort_planes_by_passengers_number_with_prefix(prefix)
            print("")

        elif option == 12:
            # Sort Planes by Concatenated String
            repo.sort_planes_by_concatenated_string()
            print("")

        elif option == 13:
            # Identify Planes with Passports starting with the same 3 letters
            result_planes = repo.filter_planes_by_passenger_passport()
            print("Planes with Passports starting with the same 3 letters:")
            for plane in result_planes:
                print(f"Plane {plane.get_number()} to {plane.get_destination()}")
            print("")

        elif option == 14:
            # Identify Passengers in a Plane with a given string
            plane_index = read_plane_index(repo)
            string = input("Enter string: ")
            result_passengers = repo.filter_passengers_containing_string(string, plane_index)
            print("Passengers in the Plane containing the given string:")
            for passenger in result_passengers:
                print(f"{passenger.get_first_name()} {passenger.get_last_name()}")
            print("")

        elif option == 15:
            # Identify Plane with a Passenger of a given name
            first_name = input("Enter passenger's first name: ")

            last_name = input("Enter passenger's last name: ")
            result_planes = repo.filter_plane_with_passenger(first_name, last_name)
            print("Planes containing the given passenger:")
            for plane in result_planes:
                print(f"Plane {plane.get_number()} to {plane.get_destination()}")
            print("")

        elif option == 16:
            plane_index = read_plane_index(repo)
            k = read_number()
            result = repo.passengers_group(plane_index, k).copy()

            if not result:
                print(None)

            for group in result:
                for pas in group:
                    print(f"{pas.get_first_name()} {pas.get_last_name()}")
                print('')

        elif option == 17:
            k = read_number()
            result = repo.planes_group(k).copy()

            if not result:
                print(None)

            for group in result:
                for plane in group:
                    print(f"{plane.get_company()} {plane.get_destination()}")
                print('')

        else:
            print("Invalid option. Please choose a valid option.")


if __name__ == "__main__":
    user_interface()
